#spark-submit task1.py /user/ecc290/HW1data/parking-violations.csv /user/ecc290/HW1data/open-violations.csv

#from __future__ import print_function

import sys
from operator import add
from pyspark import SparkContext
from csv import reader

if __name__ == "__main__":
    sc = SparkContext()

    lines = sc.textFile(sys.argv[1], 1)
    lines = lines.mapPartitions(lambda x: reader(x))

    def Mymap(x):
	weekend = [05,06,12,13,19,20,26,27]
        if isinstance(x[1][0], basestring):
            if(int(x[1][0]) in weekend):
        	return (x[0],[1,0]) 
            else: 
                return (x[0],[0,1])
	return x

    t1 = lines.map(lambda line: (str(line[2]) ,[str(line[1])[-2:], str(line[1])[-2:]])) \
		.map(lambda x: Mymap(x))
    t2 = t1.reduceByKey(lambda x,y: [x[0]+y[0], x[1]+y[1]])
    t3 = t2.map(lambda x: '%s\t%.2f, %.2f' % (x[0], float(x[1][0])/8.0, float(x[1][1])/23.0))
    #t4 = t1.collect()
    #print t4
    t3.saveAsTextFile("task7.out")

    sc.stop()

