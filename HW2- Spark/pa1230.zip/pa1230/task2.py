#spark-submit task1.py /user/ecc290/HW1data/parking-violations.csv /user/ecc290/HW1data/open-violations.csv

#from __future__ import print_function

import sys
from operator import add
from pyspark import SparkContext
from csv import reader

if __name__ == "__main__":
    sc = SparkContext()

    lines = sc.textFile(sys.argv[1], 1)
    lines = lines.mapPartitions(lambda x: reader(x))

    t1 = lines.map(lambda line: (str(line[2]),1)) \
		.reduceByKey(lambda x,y: x+y)
	
    t2 = t1.map(lambda x: '%s\t%d' % (x[0], x[1]))
    t2.saveAsTextFile("task2.out")
    sc.stop()

