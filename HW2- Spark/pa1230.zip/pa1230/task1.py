#spark-submit task1.py /user/ecc290/HW1data/parking-violations.csv /user/ecc290/HW1data/open-violations.csv

#from __future__ import print_function

import sys
from operator import add
from pyspark import SparkContext
from csv import reader
MM = 0
YY = 0
if __name__ == "__main__":
    sc = SparkContext()

    lines = sc.textFile(sys.argv[1], 1)
    lines = lines.mapPartitions(lambda x: reader(x))
    lines2 = sc.textFile(sys.argv[2], 1)
    lines2 = lines2.mapPartitions(lambda x: reader(x))
    lines = lines + lines2	#union() 

    #Mycoll = sentences.collect()
    def maps (row):
        if len(row) == 22:
		#MM +=1
		return (str(row[0]), str(row[14]) + ', ' + str(row[6]) + ', ' + str(row[2]) + ', ' + str(row[1]))
        else:
		#YY+=1
		return (str(row[0]), '1')


    def remove(t):
        final = []    
        for item in t:
            if(len(item[1])) == 1:
                for key in item[1]:
                    if(len(key)> 3):
                        final.append((item[0], key))
        return final

    
    t1 = lines.map(lambda x: maps(x)) \
        .groupByKey().collect() 
 
    #my = sc.parallelize([MM,YY])
    #my.saveAsTextFile("task1t.out")
    t2 = remove(t1)
    t3 = sc.parallelize(t2).map(lambda x: '%s\t%s' % (x[0],x[1]))
    t3.saveAsTextFile("task1.out")






    sc.stop()


    def GenBig(Coll):
    	prevWord = None
    	result =[ ]
   	for sentence in Coll:
        	sentence = sentence.strip()
        	Isfirst = True
       	 	words = sentence.split(' ')
        	for word in words:
            		if(Isfirst):
                		prevWord = word
               	 		Isfirst = False
            		else: 
                		result.append(((prevWord,word),1))
                		prevWord = word
    	return result    



