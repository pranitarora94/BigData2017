#spark-submit task1.py /user/ecc290/HW1data/parking-violations.csv /user/ecc290/HW1data/open-violations.csv

#from __future__ import print_function

import sys
from operator import add
from pyspark import SparkContext
from csv import reader

if __name__ == "__main__":
    sc = SparkContext()

    lines = sc.textFile(sys.argv[1], 1)
    lines = lines.mapPartitions(lambda x: reader(x))

    def MyMaps(x):
    	if str(x[16]) == 'NY':
    		return ('NY', 1)
    	else:
    		return ('Other',1)

    t1 = lines.map(lambda x: MyMaps(x)) \
		.reduceByKey(lambda x,y: x+y)
    
    t2 = t1.map(lambda x: '%s\t%d' % (x[0], x[1]))
    t2.saveAsTextFile("task4.out")
    sc.stop()

