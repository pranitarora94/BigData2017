#!/usr/bin/env python

from operator import itemgetter
import sys
import string
#import numpy

current_summ_num = None
current_value = None
HaveOpen = False
HavePark = False
# input comes from STDIN
for line in sys.stdin:
    # remove leading and trailing whitespace
    line = line.strip()

    # parse the input we got from mapper.py
    
    summ_num, value = line.split('\t', 1)
    # convert value (currently a string) to int
    #try:
    #    value = int(value)
    #except ValueError:
        # value was not a number, so silently
        # ignore/discard this line
    #    continue

    # this IF-switch only works because Hadoop sorts map output
    # by key (here: word) before it is passed to the reducer
    if current_summ_num == summ_num:
    	temp = value.split(',')
	if(len(temp) > 1):
            HavePark = True
            current_value = value
        else:
            HaveOpen = True
    else:
        if current_summ_num:
            # write result to STDOUT
                if HavePark and not HaveOpen:
                    print '%s\t%s' % (current_summ_num, current_value)
        current_value = None
        current_summ_num = summ_num

        temp = value.split(',')
	#print len(temp)
        if len(temp) > 1:
            HavePark = True
            HaveOpen = False
            current_value = value
        else:
            HaveOpen = True
            HavePark = False

# do not forget to output the last word if needed!
if current_summ_num == summ_num:
    if HavePark and not HaveOpen:
        print '%s\t%s' % (current_summ_num, current_value)
