#!/usr/bin/env python


import sys
import string
import os
from csv import reader
#import numpy
#parking
#summons_number[0],issue_date[1],violation_code[2],violation_county[3],violation_description[4],
#violation_location[5],violation_precinct[6],violation_time[7], time_first_observed[8],meter_number[9],
#issuer_code[10], issuer_command[11],issuer_precinct[12],issuing_agency[13],plate_id[14],plate_type[15],
#registration_state[16],street_name[17],vehicle_body_type[18],vehicle_color[19],vehicle_make[20],vehicle_year[21]

#summ_no.,issDat,VioCd,Cou,Des,Loc,,time,,,iss_cd,cmd,pre,agn,plate,ty,stat,street_,body_type,col,make,year
#1307964308,2016-03-07,14,NY,,1,1,1040P,,-,160307,0001,1,K,GBH2444,PAS,NY,N/S WARREN ST,SDN,BLACK,HONDA,2008
#1362655727,2016-03-02,98,BX,,45,45,0910P,,-,945115,0043,43,X,GKZ2313,PAS,NY,PHILPS,SUBN,WHITE,JEEP,1999
#1363178234,2016-03-01,21,NY,,34,34,0836A,,-,903530,MN12,0,S,N346594,COM,99,POST AVE,SDN,SILVE,FORD,0
#1365797030,2016-03-02,74,K,,67,67,1039P,,-,952865,0067,67,P,GDP2624,PAS,NY,C/O E 53,VAN,WHITE,DODGE,1999


#open
#summons_number[0], plate[1], license_type[2], county[3], state[4], precinct[5], issuing_agency[6], violation[7], 
#violation_status[8], issue_date[9],violation_time[10], judgment_entry_date[11],amount_due[12], payment_amount[13], 
#penalty_amount[14], fine_amount[15], interest_amount[16], reduction_amount[17]

# summ_num, plate, type,cou,st,precinct,issuing_agency, violation ..........,,,, violation_status, iss_date, vio_time,jud_dat,amt,pay,pen,fin,int,red
#1313540912,T694322C,OMT,NY,NY,17,OTHER/UNKNOWN AGENCIES,NO STANDING-DAY/TIME LIMITS,HEARING HELD-GUILTY,03/18/2016,10:38A,,0.00,115.00,0,115,0.00,0.00
#1335664579,XU694Z,PAS,NY,NJ,1,FIRE DEPARTMENT,FIRE HYDRANT,,03/21/2016,01:01P,,0.00,125.00,10,115,0.00,0.00
#1345459683,GGP2934,PAS,K,NY,84,CON RAIL,NO STANDING-EXC. AUTH. VEHICLE,,03/15/2016,08:00A,,0.00,105.00,10,95,0.00,0.00
#1363047231,HXL8614,PAS,K,PA,60,DEPARTMENT OF SANITATION,NO PARKING-STREET CLEANING,,03/07/2016,11:46A,,0.00,75.00,30,45,0.00,0.00


# myfile = os.environ.get(mapreduce_map_input_file)

######for parking#####
for line in sys.stdin:
    # remove leading and trailing whitespace
    #line = line.strip()
    # split the line into words
    
    #words = line.split()
    # increase counters
    #for word in words:
        # write the results to STDOUT (standard output);
        # what we output here will be the input for the
        # Reduce step, i.e. the input for reducer.py
        #
        # tab-delimited; the trivial word count is 1
    infile = [line]
    for word in reader(infile):
        row = word
    #row = line.split(',')
    if len(row) ==22:
        p_id = row[14]
        r_state = str(row[16])
        if r_state and p_id:
            print '%s,%s\t%s' % (p_id, r_state, '1')


    
    


