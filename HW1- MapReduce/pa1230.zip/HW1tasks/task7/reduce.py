#!/usr/bin/env python


from operator import itemgetter
import sys
#import numpy

current_my_key = None
current_Week_count = 0
current_Weekend_count = 0
my_key = None
weekend = [05,06,12,13,19,20,26,27]
# input comes from STDIN
for line in sys.stdin:
    # remove leading and trailing whitespace
    line = line.strip()

    # parse the input we got from mapper.py
    my_key, count = line.split('\t', 1)

    # convert count (currently a string) to int
    day = count
    try:
        day = int(day)
    except ValueError:
        # count was not a number, so silently
        # ignore/discard this line
        continue

    # this IF-switch only works because Hadoop sorts map output
    # by key (here: word) before it is passed to the reducer
    if current_my_key == my_key:
        if(day in weekend):
		current_Weekend_count += 1
        else:
            	current_Week_count +=1
    else:
        if current_my_key:
            # write result to STDOUT
            averWeek = float(current_Week_count)/float(23)
            averWeekend = float(current_Weekend_count)/float(8)
            print '%s\t%.2f, %.2f' % (current_my_key, averWeekend, averWeek)
        current_my_key = my_key
        current_Weekend_count = 0
        current_Week_count = 0
        if(day in weekend):
            current_Weekend_count += 1
        else:
            current_Week_count +=1

# do not forget to output the last word if needed!
if current_my_key == my_key:
    averWeek = float(current_Week_count)/float(23)
    averWeekend = float(current_Weekend_count)/float(8)
    print '%s\t%.2f, %.2f' % (current_my_key, averWeekend, averWeek)


