#!/usr/bin/env python


from operator import itemgetter
import sys
#import numpy

current_l_type = None
current_sum = 0
count = 0
l_type = None

# input comes from STDIN
for line in sys.stdin:
    # remove leading and trailing whitespace
    line = line.strip()

    # parse the input we got from mapper.py
    l_type, sum = line.split('\t', 1)
    # convert sum (currently a string) to int
    try:
        sum = float(sum)
    except ValueError:
        # sum was not a number, so silently
        # ignore/discard this line
        continue

    # this IF-switch only works because Hadoop sorts map output
    # by key (here: word) before it is passed to the reducer
    if current_l_type == l_type:
        current_sum += sum
        count +=1
    else:
	#print l_type
	#print current_l_type + ' cuur'
        if current_l_type:
            # write result to STDOUT
#       	    print 'count ' + count
	    if count>0: 
		aver = float(current_sum) / count 
            	print '%s\t%.2f, %.2f' % (current_l_type, current_sum, aver)
        current_sum = sum
        current_l_type = l_type
        count = 1

# do not forget to output the last word if needed!
if count>0:
	aver = float(current_sum) / count
	if current_l_type == l_type:
    		print '%s\t%.2f, %.2f' % (current_l_type, current_sum, aver)



