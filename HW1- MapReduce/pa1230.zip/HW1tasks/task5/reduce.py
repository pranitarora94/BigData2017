#!/usr/bin/env python


from operator import itemgetter
import sys
#import numpy

current_my_key = None
current_count = 0
my_key = None
max_key = None
max_count = 0

# input comes from STDIN
for line in sys.stdin:
    # remove leading and trailing whitespace
    line = line.strip()

    # parse the input we got from mapper.py
    my_key, count = line.split('\t', 1)

    # convert count (currently a string) to int
    try:
        count = int(count)
    except ValueError:
        # count was not a number, so silently
        # ignore/discard this line
        continue

    # this IF-switch only works because Hadoop sorts map output
    # by key (here: word) before it is passed to the reducer
    if current_my_key == my_key:
        current_count += count
    else:
	#print current_my_key
	#print my_key
        if current_my_key:
            # write result to STDOUT
            #print '%s\t%s' % (current_my_key, current_count)
            if current_count>max_count: 
                #print count
		#print current_my_key
		max_count = current_count
                max_key = current_my_key
        current_count = count
        current_my_key = my_key

# do not forget to output the last word if needed!
if current_my_key == my_key:
    if current_count>max_count: 
                max_count = curent_count
                max_key = current_my_key

#print 'max'
print '%s\t%s' % (max_key, max_count)



